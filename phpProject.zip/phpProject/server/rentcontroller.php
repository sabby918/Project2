<?php
include "sanitization.php";
//include "connection.php";
session_start();
$result = "";
//require_once 'connection.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if (isset($_POST['type'])) { // && is_session_active()
    //session_regenerate_id(); //regenerate the session to prevent fixation
    //$_SESSION['start'] = time(); //reset the session start time
    $request_type = sanitizeMYSQL($connection, $_POST['type']);
    //$request_type = $_POST['findcar'];
   $result = get_cars($connection);
   echo $result;
}
function get_cars($connection) {
    //$final = array();
    //$final["rented_cars"] = array();
    $query = "SELECT Car.Picture, Car.Picture_type, Car.CarSpecsID, CarSpecs.Make, CarSpecs.Model, CarSpecs.YearMade, CarSpecs.Size, Rental.ID as rental_id, Rental.rentDate as rent_date "
            . "FROM Car INNER JOIN CarSpecs ON Car.CarSpecsID = CarSpecs.ID INNER JOIN Rental ON Car.ID = Rental.carID";
    
    $result = mysqli_query($connection, $query);
    $text = "";
    $final_result=array();
    if (!$result)
    {       
       return json_encode($array);
    }
    else {
        $row_count = mysqli_num_rows($result);
        for ($i = 0; $i < $row_count; $i++) {
            $row = mysqli_fetch_array($result);
            $array = array();
            $array["make"] = $row["Make"];
            $array["model"] = $row["Model"];
            $array["year"] = $row["YearMade"];
            $array["size"] = $row["Size"];         
            $array["rental_ID"] = $row["rental_ID"];
            $array["rent_date"] = $row["rent_date"];
            $array["picture"] = 'data:' . $row["Picture_type"] . ';base64,' . base64_encode($row["Picture"]);
            $final_result[] = $array;
        }
    }
    return json_encode($final_result);
        
}

