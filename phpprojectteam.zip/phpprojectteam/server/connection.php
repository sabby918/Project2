<?php 


  
  $db_hostname = 'kc-sce-appdb01';
  $db_database = "skst4b";
  $db_username = "skst4b";
  $db_password = "ZVZoyHOO3Oamb";
  

 $connection = mysqli_connect($db_hostname, $db_username,$db_password,$db_database);
 
 if (!$connection)
    die("Unable to connect to MySQL: " . mysqli_connect_errno());


?>
