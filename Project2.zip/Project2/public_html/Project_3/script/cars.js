$(document).ready(init);

function init() {

}
